<?php
	header('Content-Type: text/html;charset=UTF-8');
?>
<div class="right-bar">
  <div  class="right-bar-box">
    <ul>
      <li class="login-right-1 right-bar-list">
        <a href="#" class="login-right-box "><span class="login-right"></span></a>
        <!-- right-modal-1 -->
        <div class="right-modal-1 right-modal">
          <p class="close"><a href="#">&times;</a></p>
          <div class="login-avatar">
            <a  href="#">
              <img class="my_pic" src="images/avatar-default.jpg" alt=""/>
            </a>
            <p class="login-avatar-re">你好！请 <a href="#">登录</a> | <a href="#">注册</a></p>
          </div>
          <div class="login-middle">
            <ul>
              <li><a href="#"><span class="right-myBook"></span><p>我的订单</p></a></li>
              <li><a href="#"><span class="right-myMassge"></span><p>我的消息</p></a></li>
            </ul>
          </div>
          <div class="right-myVip"><a href="#">会员俱乐部</a></div>
        </div>
      </li>
      <li  class="login-right-2 right-bar-list">
        <a href="#">
          <span class="quan-right "></span>
        </a>
        <!-- right-modal-2 -->
        <div class="right-modal-2 right-modal">
          <p><a href="">我的优惠券</a></p>
        </div>
      </li>
      <li class="login-right-3 right-bar-list">
          <a href="#"><span class="brand-right"></span>
          </a>
          <!-- right-modal-3 -->
          <div class="right-modal-3 right-modal">
            <p><a href="">我收藏的品牌</a></p>
          </div>
      </li>
      <li class="login-right-4 right-bar-list"><a href="#"><span class="goods-right"></span></a>
        <!-- right-modal-4 -->
          <div class="right-modal-4 right-modal">
            <p><a href="">我收藏的商品</a></p>
          </div>
      </li>
      <li class="login-right-5 right-bar-list"><a href="#" class="cart-right-box"><span class="cart-right"></span><p>购物袋</p><b>0</b></a></li>
    </ul>
  </div>
</div>